package com.sprint.service;

import java.util.Date;

import com.sprint.exceptions.TransactionRecordNotFoundException;
import com.sprint.models.Transaction;

public interface TransactionService {
// public Transaction getTransactionByBookingId(Long bookingId)throws TransactionRecordNotFoundException;
// public Transaction getTransactionByCustomerId(Long Customer);
// public Transaction getAllTransactionByDateAndTime(Date date);
 }
