package com.sprint.exceptions;

public class BookingNotFoundException extends Exception{

	public BookingNotFoundException()
	{
		
	}

	public BookingNotFoundException(String s) {
		super(s);
		
	}

}
