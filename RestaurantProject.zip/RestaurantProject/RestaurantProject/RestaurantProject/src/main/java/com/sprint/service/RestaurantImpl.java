package com.sprint.service;

import java.util.Date;

public class RestaurantImpl implements RestaurantService{

	@Override
	public void getTablesAvailableOnDateTime(Date date) {
		
		
	}

	@Override
	public void getTablesBySeating() {
		
		
	}

	@Override
	public void getAllAvailableTables() {
		
		
	}

}
