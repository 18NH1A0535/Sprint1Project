package com.sprint;

public class controller {

	public controller() {
		// TODO Auto-generated constructor stub
	}

}
