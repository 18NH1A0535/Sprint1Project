package com.sprint;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.web.servlet.MockMvc;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.sprint.service.AdminService;

@WebMvcTest
public class AdminControllerTests {

	@Autowired
	private MockMvc mockMvc;
	
	@MockBean
	private AdminService adminService;
	
	@Autowired
	private ObjectMapper objectMapper;
	public AdminControllerTests() {
		// TODO Auto-generated constructor stub
	}
}


