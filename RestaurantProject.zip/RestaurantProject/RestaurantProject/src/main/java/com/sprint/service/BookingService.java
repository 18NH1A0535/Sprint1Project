package com.sprint.service;


import java.time.LocalDate;
import java.time.LocalTime;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import com.sprint.exceptions.BookingNotFoundException;
import com.sprint.exceptions.NoBookingFoundException;
import com.sprint.models.Booking;

public interface BookingService {
	List<Booking> findBookingByDate(LocalDate date);
	//List<Booking> getBookingsByCustomerId(Long customerId);
	Booking updateBooking(long bookingId,LocalTime newTime) throws NoBookingFoundException;
	Booking createBooking(LocalDate date ,int numberOfGuests);
	public void cancelBooking(Long bookingId) throws BookingNotFoundException;
}