package com.sprint.exceptions;

public class NoBookingFoundException extends Exception {

	public NoBookingFoundException(String s) {
		super(s);
	}

}
