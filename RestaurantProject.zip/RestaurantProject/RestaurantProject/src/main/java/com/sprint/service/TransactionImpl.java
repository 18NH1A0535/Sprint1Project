package com.sprint.service;

import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;

import com.sprint.models.Transaction;

public class TransactionImpl implements TransactionService{
	
	
	@Override
	public Transaction getTransactionByBookingId(Long BookingId) {
		
		return null;
	}

	@Override
	public Transaction getTransactionByCustomerId(Long Customer) {
		
		return null;
	}

	@Override
	public Transaction getAllTransactionByDateAndTime(Date date) {
		
		return null;
	}

	

}
