package com.sprint.exceptions;

public class BookingAlreadyExistsException extends Exception
{

	public BookingAlreadyExistsException()
	{
		super();
	}
	public BookingAlreadyExistsException(String s)
	{
		super(s);
	}

}
