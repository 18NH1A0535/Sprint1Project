package com.sprint.exceptions;

public class CustomerNotFoundException extends Exception{
	public CustomerNotFoundException() {
		super();
	}
	
	public CustomerNotFoundException(String s) {
		super(s);
	}

}
